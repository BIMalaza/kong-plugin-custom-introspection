# Kong custom instrospection

This plugin does custom introspection and modifies the request

## Supported Kong Releases
Kong >= 1.3.x